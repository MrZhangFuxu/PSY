# 儿童和青少年焦虑障碍治疗药物及常用剂量

![儿童和青少年焦虑障碍治疗药物及常用剂量](https://www.shsmu.top/wp-content/uploads/2022/12/8D781646-7491-4A54-9A3E-644E92AC0AD4-1024x887.jpeg )

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 300.