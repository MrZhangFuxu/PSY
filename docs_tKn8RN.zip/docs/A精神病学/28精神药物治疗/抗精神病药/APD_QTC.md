# 抗精神病药对QTc的影响

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/86-88表2.23-抗精神病药对-QTc的影响15.16.22-45_页面_1-1536x947.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/86-88表2.23-抗精神病药对-QTc的影响15.16.22-45_页面_2-1192x1536.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/86-88表2.23-抗精神病药对-QTc的影响15.16.22-45_页面_3-1536x631.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/86-88表2.23-抗精神病药对-QTc的影响15.16.22-45_页面_4-1536x536.jpg)


> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 86-88.