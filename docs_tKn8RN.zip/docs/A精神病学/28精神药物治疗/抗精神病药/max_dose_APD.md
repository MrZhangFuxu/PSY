# 欧盟批准的抗精神病药最大剂量速查表
`最大剂量 抗精神病药 处方指南`

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/16-1194x1536.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/17-1536x810.jpg)

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 18-19.
