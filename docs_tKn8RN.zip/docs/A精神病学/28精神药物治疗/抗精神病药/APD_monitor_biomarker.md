# 抗精神病药治疗者的代谢指标监测

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/34-1536x844.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/35-1452x2048.jpg)

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/36-1536x727.jpg)


> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 34-36.