# 电抽搐治疗与精神药物

![电抽搐治疗与精神药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20221128124129-752x1024.jpg )

![电抽搐治疗与精神药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20221128124139-1024x828.jpg)

> \[英\]DAVID TAYLOR, 等. MAUDSLEY精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 217-218.*