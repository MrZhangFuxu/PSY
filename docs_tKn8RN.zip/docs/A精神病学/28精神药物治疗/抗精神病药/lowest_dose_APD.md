# 常用抗精神病药治疗精神分裂症最低有效日剂量  

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20221018201336-1536x1129.jpg)  
![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20221018201347-1536x434.jpg)  

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 16-17.