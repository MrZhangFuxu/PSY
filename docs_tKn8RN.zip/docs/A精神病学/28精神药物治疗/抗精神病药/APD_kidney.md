# 肾功能损害与精神科药物

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_1-1-1024x746.jpg)

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_2-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_3-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_4-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_5-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_6-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_7-791x1024.jpg )

![肾功能损害与精神科药物](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%8D%AF%E7%89%A9472-479_%E9%A1%B5%E9%9D%A2_8-791x1024.jpg)

> \[英\]DAVID TAYLOR, 等. MAUDSLEY精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 472-479.