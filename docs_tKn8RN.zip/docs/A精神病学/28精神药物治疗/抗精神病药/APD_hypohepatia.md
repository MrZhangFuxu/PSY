# 抗精神病药在肝功能损害中的应用  

![](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%A1%A87.21-%E8%82%9D%E5%8A%9F%E8%83%BD%E6%8D%9F%E5%AE%B3%E6%97%B6%E4%BD%BF%E7%94%A8%E7%B2%BE%E7%A5%9E%E7%A7%91%E8%8D%AF%E7%89%A9%E7%9A%84%E5%BB%BA%E8%AE%AE_%E9%A1%B5%E9%9D%A2_1-791x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%A1%A87.21-%E8%82%9D%E5%8A%9F%E8%83%BD%E6%8D%9F%E5%AE%B3%E6%97%B6%E4%BD%BF%E7%94%A8%E7%B2%BE%E7%A5%9E%E7%A7%91%E8%8D%AF%E7%89%A9%E7%9A%84%E5%BB%BA%E8%AE%AE_%E9%A1%B5%E9%9D%A2_2-791x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/11/%E8%A1%A87.21-%E8%82%9D%E5%8A%9F%E8%83%BD%E6%8D%9F%E5%AE%B3%E6%97%B6%E4%BD%BF%E7%94%A8%E7%B2%BE%E7%A5%9E%E7%A7%91%E8%8D%AF%E7%89%A9%E7%9A%84%E5%BB%BA%E8%AE%AE_%E9%A1%B5%E9%9D%A2_3-791x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/11/7.21-%E8%82%9D%E5%8A%9F%E8%83%BD%E6%8D%9F%E5%AE%B3%E6%97%B6%E4%BD%BF%E7%94%A8%E7%B2%BE%E7%A5%9E%E7%A7%91%E8%8D%AF%E7%89%A9%E7%9A%84%E5%BB%BA%E8%AE%AE_%E9%A1%B5%E9%9D%A2_4-scaled-e1668871049170-1024x660.jpg)

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 484-487.

