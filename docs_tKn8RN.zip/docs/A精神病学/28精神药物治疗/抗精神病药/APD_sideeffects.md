# 抗精神病药物相关不良反应  

![](https://www.shsmu.top/wp-content/uploads/2022/10/37%E8%A1%A82.7%E6%8A%97%E7%B2%BE%E7%A5%9E%E7%97%85%E8%8D%AF%E7%9B%B8%E5%85%B3%E4%B8%8D%E8%89%AF%E5%8F%8D%E5%BA%94-1187x1536.jpg)

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 37.