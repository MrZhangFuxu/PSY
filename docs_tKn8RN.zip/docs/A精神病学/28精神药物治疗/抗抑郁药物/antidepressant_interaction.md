# 抗抑郁药的相互作用与常用剂量
 

![]( https://www.shsmu.top/wp-content/uploads/2022/12/EC453A11-E82D-43E1-8FC5-2B28C66B6F47.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/898EADDC-9670-4976-80F4-858A8C92772B.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/A11E6FDF-4BA4-4D41-983F-51AFA9074D21-2048x1183.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/04576672-E63B-4859-AC27-F2568BE81095.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/AD90971E-A7A4-4717-9762-41CE16D24C2A.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/68DBBC9A-32A3-4979-B1BD-23FF109209AC.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/D7697427-2DAE-4C86-9312-0470477A1E18.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/AF099326-8A13-4DBB-A3C3-671256DA7890.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/3A831C79-5F38-4EEA-9A9C-55468392CB3D.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/1C4830CC-D13F-4573-A1A9-0DEC62850FDF.jpeg)
![](https://www.shsmu.top/wp-content/uploads/2022/12/4B10281A-94F0-429C-8109-36F18FDC6F76.jpeg)

> [英]DAVID TAYLOR, 等. MAUDSLEY精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 186-196.