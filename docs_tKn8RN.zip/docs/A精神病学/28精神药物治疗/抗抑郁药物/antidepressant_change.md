# 抗抑郁药：换药和停药  

![](https://www.shsmu.top/wp-content/uploads/2022/10/241-244-%E8%A1%A84.15-%E6%8A%97%E6%8A%91%E9%83%81%E8%8D%AF%EF%BC%9A%E6%8D%A2%E8%8D%AF%E5%92%8C%E5%81%9C%E8%8D%AF%C2%B0_%E9%A1%B5%E9%9D%A2_1-792x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/10/241-244-%E8%A1%A84.15-%E6%8A%97%E6%8A%91%E9%83%81%E8%8D%AF%EF%BC%9A%E6%8D%A2%E8%8D%AF%E5%92%8C%E5%81%9C%E8%8D%AF%C2%B0_%E9%A1%B5%E9%9D%A2_2-791x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/10/241-244-%E8%A1%A84.15-%E6%8A%97%E6%8A%91%E9%83%81%E8%8D%AF%EF%BC%9A%E6%8D%A2%E8%8D%AF%E5%92%8C%E5%81%9C%E8%8D%AF%C2%B0_%E9%A1%B5%E9%9D%A2_3-791x1024.jpg)
![](https://www.shsmu.top/wp-content/uploads/2022/10/241-244-%E8%A1%A84.15-%E6%8A%97%E6%8A%91%E9%83%81%E8%8D%AF%EF%BC%9A%E6%8D%A2%E8%8D%AF%E5%92%8C%E5%81%9C%E8%8D%AF%C2%B0_%E9%A1%B5%E9%9D%A2_4-792x1024.jpg)  

> [英]David Taylor, 等. Maudsley精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 241-244.
