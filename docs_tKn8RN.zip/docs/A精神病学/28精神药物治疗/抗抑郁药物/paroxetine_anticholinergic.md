# 帕罗西汀（paroxetine）的抗胆碱能作用  

帕罗西汀对毒蕈碱受体阻断作用强，是唯一和M受体结合的SSRI，对此引起的尿潴留可予氯贝胆碱10mg/d治疗。

> 唐宏宇, 方贻儒. 精神病学. 第二版. 北京: 人民卫生出版社, 2020:86.

![Alt](https://www.shsmu.top/wp-content/uploads/2022/10/image.png)  

> American Geriatrics Society 2012 Beers Criteria Update Expert Panel. American Geriatrics Society updated Beers Criteria for potentially inappropriate medication use in older adults. J Am Geriatr Soc. 2012 Apr;60(4):616-31.