# 常用抗抑郁药使用最小剂量en

![](https://shsmu.top:442/index.php/s/STJ4A9a96BCHGiq/preview)

# STAR*D 治愈率en

![](https://shsmu.top:442/index.php/s/Wt3cS3PJQQ5HmYq/preview)


> Taylor, D.M., Barnes, T.R.E., Young, A.H., 2021. The Maudsley Prescribing Guidelines in Psychiatry, 14th Edition, 14th ed, The maudsley prescribing guidelines series. John Wiley & Sons, Hoboken.p312,p317.