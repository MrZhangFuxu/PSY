# 心境稳定剂的作用机制

![心境稳定剂的作用机制](https://www.shsmu.top/wp-content/uploads/2022/12/2BADC35A-ECD6-4790-B10C-DEBAE372EAF3-1024x615.jpeg)

> [英]Stephen M. Stahl, 等. Stahl精神药理学精要(第3版). 司天梅, 等. 译. 北京: 北京大学医学出版社, 2011: 583.