# 孕期精神病药物使用建议  

![](https://www.shsmu.top/wp-content/uploads/2023/03/表7.9-孕期精神药物使用建议（尽量减少胎儿暴露的药物数量）-1536x1097.jpg)

> [英]DAVID TAYLOR, 等. MAUDSLEY精神科处方指南. 司天梅, 等, 译. 北京: 人民卫生出版社, 2017: 450.