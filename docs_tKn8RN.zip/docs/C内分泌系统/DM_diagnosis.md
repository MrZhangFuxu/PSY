# WHO糖尿病诊断标准(1999)  

![](https://www.shsmu.top/wp-content/uploads/2022/10/img_0705-1536x1019.jpg)

> 陈灏珠, 钟南山, 陆再英等. 内科学(第9版), 北京: 人民卫生出版社, 2018: 733.
