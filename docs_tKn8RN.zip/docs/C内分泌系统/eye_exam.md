# 甲亢的眼部检查  

<br><iframe src="//player.bilibili.com/player.html?aid=499711813&amp;bvid=BV1aK411P7dK&amp;cid=238994206&amp;page=1" frameborder="no" scrolling="no" allowfullscreen="allowfullscreen" width="600" height="400"> </iframe>
<hr>
<p>来自<strong style="font-style: italic; color: inherit; font-family: var( --e-global-typography-text-font-family ), Sans-serif; text-transform: uppercase;"><a href="https://space.bilibili.com/556845077">知识点受体激动剂</a></strong></p>